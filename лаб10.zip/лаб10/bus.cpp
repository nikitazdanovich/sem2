#include "bus.h"
#include <iostream>

using namespace std;

Bus::Bus(const string& n, int s, int route, int capacity, const string& fuel)
    : PublicTransport(route, capacity), Vehicle(n, s), fuelType(fuel) {}

void Bus::print() const {
    cout << "____Автобус____" << endl;
    printVehicle();
    printPublicTransport();
    cout << "Тип топлива: " << fuelType << endl;
}