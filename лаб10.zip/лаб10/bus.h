#ifndef BUS_H
#define BUS_H

#include "vehicle.h"
#include "public_transport.h"
#include <string>

class Bus : public PublicTransport, public Vehicle {
private:
    std::string fuelType;

public:
    Bus(const std::string& n, int s, int route, int capacity, const std::string& fuel);
    void print() const;
};

#endif