#ifndef PUBLIC_TRANSPORT_H
#define PUBLIC_TRANSPORT_H

class PublicTransport {
protected:
    int routeNumber;
    int passengerCapacity;

public:
    PublicTransport(int route, int capacity);
    void printPublicTransport() const;
};

#endif 