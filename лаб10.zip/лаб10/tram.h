#ifndef TRAM_H
#define TRAM_H

#include "public_transport.h"

class Tram : public PublicTransport {
private:
    int electricLineVoltage;

public:
    Tram(int route, int capacity, int voltage);
    void print() const;
};

#endif