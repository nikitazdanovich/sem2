#ifndef VEHICLE_H
#define VEHICLE_H

#include <string>

class Vehicle {
protected:
    std::string name;
    int maxSpeed;

public:
    Vehicle(const std::string& n = "Unknown", int s = 0);
    void printVehicle() const;
};

#endif