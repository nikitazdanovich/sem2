#pragma once
#ifndef CAR_H
#define CAR_H

#include "Transport_Unit.h"

class Car : public TransportUnit {
public:
    double calculateToll(double distance) const override;
};

#endif