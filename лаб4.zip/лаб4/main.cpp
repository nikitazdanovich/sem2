#include <iostream>
#include "car.h"
#include "truck.h"
#include "Transport_Unit.h"
using namespace std;


int main() {
    setlocale(LC_ALL, "RU");

    Car car;
    Truck truck;

    TransportUnit* units[2];

    units[0] = &car;
    units[1] = &truck;

    double distance = 100;

    cout << "Расчет платы за " << distance << " км:\n";

    for (int i = 0; i < 2; i++) {
        cout << "Плата: " << units[i]->calculateToll(distance) << endl;
    }

    return 0;
}