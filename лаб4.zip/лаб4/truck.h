#pragma once
#ifndef TRUCK_H
#define TRUCK_H

#include "Transport_Unit.h"

class Truck : public TransportUnit {
public:
    double calculateToll(double distance) const override;
};

#endif