#include "assigned_route.h"
#include <iostream>

AssignedRoute::AssignedRoute(const Route& r, const TransportUnit* t)
    : route(r), transport(t) {}

double AssignedRoute::calculateTotalCost() const {
    return transport->calculateToll(route.getLength());
}

void AssignedRoute::printFinal() const {
    route.printInfo();
    std::cout << "Стоимость проезда: " << calculateTotalCost() << " у.е.\n\n";
}