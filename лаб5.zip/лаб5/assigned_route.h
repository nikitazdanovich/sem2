#pragma once
#include "Transport_Unit.h"
#include "route.h"

class AssignedRoute {
private:
    Route route;
    const TransportUnit* transport;

public:
    AssignedRoute(const Route& r, const TransportUnit* t);
    double calculateTotalCost() const;
    void printFinal() const;
};