#include <iostream>
#include <clocale>
#include "car.h"
#include "truck.h"
#include "route.h"
#include "assigned_route.h"

using namespace std;

int main() {
    setlocale(LC_ALL, "Russian");

    Car car;
    Truck truck;

    Route route1("Москва", "Тула", 180);
    Route route2("Казань", "Самара", 350);

    AssignedRoute assigned1(route1, &car);
    AssignedRoute assigned2(route2, &truck);

    cout << "=== Расчёт стоимости маршрутов ===\n\n";
    assigned1.printFinal();
    assigned2.printFinal();

    return 0;
}