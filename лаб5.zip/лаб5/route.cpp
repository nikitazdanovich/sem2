#include "route.h"

Route::Route(const std::string& start, const std::string& end, double len)
    : startPoint(start), endPoint(end), length(len) {}

double Route::getLength() const { return length; }

void Route::printInfo() const {
    std::cout << "Маршрут: " << startPoint << " → " << endPoint
              << " (" << length << " км)\n";
}