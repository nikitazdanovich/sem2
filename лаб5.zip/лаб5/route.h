#pragma once
#include <string>
#include <iostream>

class Route {
private:
    std::string startPoint;
    std::string endPoint;
    double length;

public:
    Route(const std::string& start, const std::string& end, double len);
    double getLength() const;
    void printInfo() const;
};