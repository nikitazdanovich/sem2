#pragma once
#ifndef Transport_Unit_H
#define Transport_Unit_H

class TransportUnit {
public:
    virtual double calculateToll(double distance) const = 0;
    virtual ~TransportUnit() = default;
}; 

#endif