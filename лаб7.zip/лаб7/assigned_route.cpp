#include "assigned_route.h"
#include <iostream>

AssignedRoute::AssignedRoute(const Route& r, std::unique_ptr<TransportUnit> t)
    : route(r), transport(std::move(t)) {}

double AssignedRoute::calculateTotalCost() const {
    return transport->calculateToll(route.getLength());
}

void AssignedRoute::printFinal() const {
    route.printInfo();
    std::cout << "Стоимость проезда: " << calculateTotalCost() << " у.е.\n";
}