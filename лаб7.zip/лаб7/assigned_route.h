#ifndef ASSIGNED_ROUTE_H
#define ASSIGNED_ROUTE_H

#include "Transport_Unit.h"
#include "route.h"
#include <memory>

class AssignedRoute {
private:
    Route route;
    std::unique_ptr<TransportUnit> transport;

public:
    AssignedRoute(const Route& r, std::unique_ptr<TransportUnit> t);
    
    double calculateTotalCost() const;
    void printFinal() const;
};

#endif