#include <iostream>
#include <clocale>
#include <memory>
#include "car.h"
#include "truck.h"
#include "route.h"
#include "assigned_route.h"

using namespace std;

int main() {
    setlocale(LC_ALL, "Russian");

    Route route1("Москва", "Тула", 180);
    Route route2("Казань", "Самара", 350);

    cout << "=== Расчёт стоимости маршрутов ===\n\n";

    AssignedRoute assigned1(route1, make_unique<Car>());
    AssignedRoute assigned2(route2, make_unique<Truck>());

    assigned1.printFinal();
    cout << "\n";
    assigned2.printFinal();

    return 0;
}